from django.shortcuts import render,redirect
from django.views import View
from .forms import *

# Create your views here.
class login(View):
    def get(self,request):
        return render(request,'login.html')
    
class home(View):
    def get(self, request):
        return render(request,'home.html')
    
class reg(View):
    def get(self, request):
        form=Regform()
        return render(request,'reg.html',{'form':form})
    
    def post(self,request):
        form=Regform(request.POST)
        if form.is_valid():
            user=form.save()
            # login(request,user)
            form.save()
            return redirect('home')
        return render(request,'reg.html',{'form':form})