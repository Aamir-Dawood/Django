from django.shortcuts import render,redirect,get_object_or_404
from app1.models import Reg

# Create your views here.

# Create your views here.

def home(request):
    return render(request,'home.html')

# def reg(request):
#     return render(request,'reg.html')

def product(request):
    return render(request,'product.html')

def about(request):
    return render(request,'about.html')

def reg(request):
    if request.method =='POST':
        fn=request.POST.get('firstname')
        ln=request.POST.get('lastname')
        mail=request.POST.get('email')
        tel=request.POST.get('telephonenumber')
        dob=request.POST.get('dob')
        gender=request.POST.get('gender')
        postal=request.POST.get('postal')
        password=request.POST.get('password')
        c_password=request.POST.get('confirmpassword')
        Reg.objects.create(fn=fn,ln=ln,mail=mail,tel=tel,dob=dob,gender=gender,postal=postal,password=password,c_password=c_password)
        print(fn,ln)
        return redirect('home')
        
    return render(request,'reg.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def reg(request):
    return render(request,'reg.html')

# def dis(qs):
#     for res in qs:
#         print(f'ID: {res.id}\n'
#               f'First_name: {res.fn}\n'
#               f'Last_name: {res.id}\n'
              
#               )