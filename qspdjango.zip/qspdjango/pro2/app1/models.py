from django.db import models

class Reg(models.Model):
    fn=models.CharField(max_length=20)
    ln=models.CharField(max_length=20)
    mail=models.CharField(max_length=20)
    tel=models.CharField(max_length=20)
    dob=models.DateField(default='2002-03-29')
    gender=models.CharField(max_length=20, default='male')
    postal=models.CharField(max_length=20, default='600001')
    password=models.CharField(max_length=20, default='abcd')
    c_password=models.CharField(max_length=20, default='abcd')
def __init__(self):
    return f'{(self.fn) (self.ln)}'

# Create your models here.
