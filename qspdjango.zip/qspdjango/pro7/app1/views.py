from django.shortcuts import render,redirect
from app1.models import Profile,SignUp

# Create your views here.
def home(request):
    return render(request,'home.html')

def profile(request):
    if request.method== 'POST':
        name=request.POST.get('name')
        age=request.POST.get('age')
        gender=request.POST.get('gender')
        mob=request.POST.get('mob')
        add=request.POST.get('add')
        Profile.objects.create(name=name,age=age,gender=gender,mob=mob,add=add)
        return redirect('home')
    return render(request,'profile.html')

def signup(request):
    if request.method== 'POST':
        name=request.POST.get('name')
        uname=request.POST.get('username')
        age=request.POST.get('age')
        gender=request.POST.get('gender')
        mob=request.POST.get('mob')
        add=request.POST.get('add')
        password=request.POST.get('password')
        c_p=request.POST.get('c_p')
        SignUp.objects.create(name=name,user=uname,age=age,gender=gender,mob=mob,add=add,password=password,c_password=c_p)
        return redirect('home')
    return render(request,'signup.html')

