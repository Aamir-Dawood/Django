from django.db import models

# Create your models here.
class Profile(models.Model):
    name=models.CharField(max_length=20)
    age=models.CharField(max_length=3)
    gender=models.CharField(max_length=7)
    mob=models.CharField(max_length=10)
    add=models.CharField(max_length=30)

class SignUp(Profile):
    user=models.CharField(max_length=15)
    password=models.CharField(max_length=15)
    c_password=models.CharField(max_length=15)