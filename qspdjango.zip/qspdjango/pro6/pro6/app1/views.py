from django.shortcuts import render,redirect,HttpResponse
from app1.models import s_table

# Create your views here.
def home(request):
    return render(request,'home.html')

def reg(request):
    if request.method=='POST':
        name=request.POST.get('name')
        age=request.POST.get('age')
        mob=request.POST.get('mob')
        Cls=request.POST.get('cls')
        s_table.objects.create(name=name, age=age , mob=mob ,cls=Cls)
        # print(name,age,mob,cls)
        return redirect('home')
    return render(request,'reg.html')

def read_tab(request):
    table=s_table.objects.all()
    return render(request,'table.html',{'table': table})

def read(request):
    if request.method=='POST':
        id=request.POST.get('id')
        print(id)
        table=s_table.objects.filter(id=id)
        return render(request,'table.html',{'table':table})
    print('hello')
    return render(request,'take_data.html')

def edit(request):
    if request.method=='POST' and request.POST.get('name'):
        id=request.POST.get('id')
        name=request.POST.get('name')
        age=request.POST.get('age')
        mob=request.POST.get('mob')
        Cls=request.POST.get('cls')
        s_table.objects.filter(id=id).update(name=name,age=age,mob=mob,cls=Cls)
        return redirect('home')
    if request.method=='POST':
        id=request.POST.get('id')
        data=s_table.objects.get(id=id)
        return render(request,'reg.html',{'data':data})
    return render(request,'take_data.html')

def delete(request):
    if request.method == 'POST':
        id= request.POST.get('id')
        s_table.objects.get(id=id).delete()
        return redirect('home')
    return render(request,'take_data.html')
