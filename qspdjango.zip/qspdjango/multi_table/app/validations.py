from django.core.exceptions import ValidationError


def validate_price(value):
    if value<=0:
        raise ValidationError('Price must be a positive integer')
    
def v_name(name):
    if len(name)<=3:
        raise ValidationError('Name should have atleast 3 charaters')
    
def v_phone(num):
    if len(num) !=10:
        raise ValidationError('Phone number must be 10 digit')
def v_desc(dec):
    if len(dec)< 10:
        raise ValidationError('Description must have atleast 10 characters')