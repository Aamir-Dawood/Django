from django.shortcuts import render,HttpResponse

# Create your views here.
def home2(request):
    return HttpResponse("<h1>This is my app2 home</h1>")

def about2(request):
    return HttpResponse("<h1>This is my app2 home</h1>")