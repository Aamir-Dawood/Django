from django.urls import path,include
from app2 import views

urlpatterns=[
    path('',views.home2,name='home2'),
    path('about/',views.about2,name='about2'),
    # path('contact',views.contact,name='contact')

]